package edu.ccrm.config;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;

/**
 * Singleton pattern implementation for application configuration
 */
public class AppConfig {
    private static AppConfig instance;
    private static final Object lock = new Object();
    
    // Configuration properties
    private final String dataFolderPath;
    private final String backupFolderPath;
    private final String exportFolderPath;
    private final DateTimeFormatter dateFormatter;
    private final DateTimeFormatter timestampFormatter;
    private final int maxCreditsPerSemester;
    private final String applicationName;
    private final String version;
    
    // Private constructor prevents instantiation
    private AppConfig() {
        this.applicationName = "Campus Course & Records Manager (CCRM)";
        this.version = "1.0.0";
        this.dataFolderPath = "data";
        this.backupFolderPath = "backups";
        this.exportFolderPath = "exports";
        this.dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.timestampFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
        this.maxCreditsPerSemester = 24;
    }
    
    // Thread-safe singleton implementation with double-checked locking
    public static AppConfig getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new AppConfig();
                }
            }
        }
        return instance;
    }
    
    // Getters
    public String getApplicationName() {
        return applicationName;
    }
    
    public String getVersion() {
        return version;
    }
    
    public String getDataFolderPath() {
        return dataFolderPath;
    }
    
    public String getBackupFolderPath() {
        return backupFolderPath;
    }
    
    public String getExportFolderPath() {
        return exportFolderPath;
    }
    
    public Path getDataPath() {
        return Paths.get(dataFolderPath);
    }
    
    public Path getBackupPath() {
        return Paths.get(backupFolderPath);
    }
    
    public Path getExportPath() {
        return Paths.get(exportFolderPath);
    }
    
    public DateTimeFormatter getDateFormatter() {
        return dateFormatter;
    }
    
    public DateTimeFormatter getTimestampFormatter() {
        return timestampFormatter;
    }
    
    public int getMaxCreditsPerSemester() {
        return maxCreditsPerSemester;
    }
    
    // Method to get Java platform information
    public String getJavaPlatformInfo() {
        StringBuilder info = new StringBuilder();
        info.append("Java Platform Information:\n");
        info.append("========================\n");
        info.append("Java SE (Standard Edition): Core Java platform for desktop and server applications\n");
        info.append("Java ME (Micro Edition): Lightweight Java platform for embedded and mobile devices\n");
        info.append("Java EE (Enterprise Edition): Extended Java platform for enterprise applications\n");
        info.append("\nCurrent Runtime:\n");
        info.append("Java Version: ").append(System.getProperty("java.version")).append("\n");
        info.append("Java Vendor: ").append(System.getProperty("java.vendor")).append("\n");
        info.append("Java Home: ").append(System.getProperty("java.home")).append("\n");
        
        return info.toString();
    }
    
    // Method to print application banner
    public void printBanner() {
        System.out.println("=".repeat(60));
        System.out.println("    " + applicationName);
        System.out.println("    Version: " + version);
        System.out.println("=".repeat(60));
        System.out.println();
    }
    
    @Override
    public String toString() {
        return String.format("AppConfig[app=%s, version=%s, dataPath=%s]", 
                applicationName, version, dataFolderPath);
    }
}