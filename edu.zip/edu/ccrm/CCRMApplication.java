package edu.ccrm;

import edu.ccrm.cli.CCRMConsole;
import edu.ccrm.config.AppConfig;

/**
 * Main application class for Campus Course & Records Manager
 * Entry point demonstrating proper Java application structure
 */
public class CCRMApplication {
    
    /**
     * Main method - entry point of the application
     * Demonstrates basic Java application structure and exception handling
     */
    public static void main(String[] args) {
        // Enable assertions for debugging (java -ea)
        assert true : "Assertions are enabled";
        
        try {
            // Get application configuration
            AppConfig config = AppConfig.getInstance();
            
            // Print Java platform information at startup
            System.out.println("Starting " + config.getApplicationName() + " v" + config.getVersion());
            System.out.println("Running on Java " + System.getProperty("java.version"));
            System.out.println();
            
            // Brief platform information as required
            System.out.println("JAVA PLATFORM OVERVIEW:");
            System.out.println("- Java SE: Standard Edition for desktop and server applications");
            System.out.println("- Java ME: Micro Edition for embedded and mobile devices"); 
            System.out.println("- Java EE: Enterprise Edition for large-scale enterprise applications");
            System.out.println();
            
            // Start the console application
            CCRMConsole console = new CCRMConsole();
            console.start();
            
        } catch (Exception e) {
            System.err.println("Application startup failed: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
        
        System.out.println("Application terminated successfully.");
        System.exit(0);
    }
}