package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Semester;
import java.util.List;
import java.util.Optional;

/**
 * Interface for Course Service operations
 */
public interface CourseService {
    Course createCourse(String code, String title, int credits, String instructorId, 
                       Semester semester, String department);
    Optional<Course> findCourseByCode(String code);
    List<Course> getAllCourses();
    List<Course> getActiveCourses();
    List<Course> getCoursesByInstructor(String instructorId);
    List<Course> getCoursesByDepartment(String department);
    List<Course> getCoursesBySemester(Semester semester);
    boolean updateCourse(Course course);
    boolean deactivateCourse(String code);
    boolean activateCourse(String code);
    boolean deleteCourse(String code);
    List<Course> searchCoursesByTitle(String titlePattern);
    int getTotalCourseCount();
}