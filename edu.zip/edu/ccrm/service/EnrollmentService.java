package edu.ccrm.service;

import edu.ccrm.domain.Enrollment;
import edu.ccrm.domain.Grade;
import java.util.List;
import java.util.Optional;

/**
 * Interface for Enrollment Service operations
 */
public interface EnrollmentService {
    Enrollment enrollStudent(String studentId, String courseCode, String semester);
    boolean unenrollStudent(String studentId, String courseCode);
    Optional<Enrollment> findEnrollment(String studentId, String courseCode);
    List<Enrollment> getEnrollmentsByStudent(String studentId);
    List<Enrollment> getEnrollmentsByCourse(String courseCode);
    List<Enrollment> getAllActiveEnrollments();
    boolean recordGrade(String studentId, String courseCode, Grade grade);
    boolean recordMarks(String studentId, String courseCode, double marks);
    boolean canEnrollStudent(String studentId, String courseCode);
    int getEnrollmentCount();
}