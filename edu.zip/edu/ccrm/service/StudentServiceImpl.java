package edu.ccrm.service;

import edu.ccrm.domain.Student;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Implementation of StudentService - demonstrates polymorphism and Stream API usage
 */
public class StudentServiceImpl implements StudentService {
    private Map<String, Student> students; // In-memory storage
    private Map<String, Student> studentsByRegNo; // Index by registration number
    
    public StudentServiceImpl() {
        this.students = new HashMap<>();
        this.studentsByRegNo = new HashMap<>();
    }
    
    @Override
    public Student createStudent(String id, String regNo, String fullName, String email, LocalDate dateOfBirth) {
        // Check if student with same ID or RegNo already exists
        if (students.containsKey(id)) {
            throw new IllegalArgumentException("Student with ID " + id + " already exists");
        }
        if (studentsByRegNo.containsKey(regNo)) {
            throw new IllegalArgumentException("Student with Registration Number " + regNo + " already exists");
        }
        
        Student student = new Student(id, regNo, fullName, email, dateOfBirth);
        students.put(id, student);
        studentsByRegNo.put(regNo, student);
        return student;
    }
    
    @Override
    public Optional<Student> findStudentById(String id) {
        return Optional.ofNullable(students.get(id));
    }
    
    @Override
    public Optional<Student> findStudentByRegNo(String regNo) {
        return Optional.ofNullable(studentsByRegNo.get(regNo));
    }
    
    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }
    
    @Override
    public List<Student> getActiveStudents() {
        // Using Stream API for filtering
        return students.values().stream()
                .filter(Student::isActive)
                .collect(Collectors.toList());
    }
    
    @Override
    public boolean updateStudent(Student student) {
        if (students.containsKey(student.getId())) {
            students.put(student.getId(), student);
            studentsByRegNo.put(student.getRegNo(), student);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean deactivateStudent(String id) {
        Student student = students.get(id);
        if (student != null) {
            student.deactivate();
            return true;
        }
        return false;
    }
    
    @Override
    public boolean activateStudent(String id) {
        Student student = students.get(id);
        if (student != null) {
            student.activate();
            return true;
        }
        return false;
    }
    
    @Override
    public boolean deleteStudent(String id) {
        Student student = students.remove(id);
        if (student != null) {
            studentsByRegNo.remove(student.getRegNo());
            return true;
        }
        return false;
    }
    
    @Override
    public List<Student> searchStudentsByName(String namePattern) {
        // Using Stream API with lambda expressions for searching
        String pattern = namePattern.toLowerCase();
        return students.values().stream()
                .filter(student -> student.getFullName().toLowerCase().contains(pattern))
                .collect(Collectors.toList());
    }
    
    @Override
    public int getTotalStudentCount() {
        return students.size();
    }
    
    // Additional utility methods
    public List<Student> getStudentsEnrolledInCourse(String courseCode) {
        return students.values().stream()
                .filter(student -> student.isEnrolledIn(courseCode))
                .collect(Collectors.toList());
    }
    
    public List<Student> getStudentsByGPARange(double minGPA, double maxGPA) {
        return students.values().stream()
                .filter(student -> {
                    double gpa = student.calculateGPA();
                    return gpa >= minGPA && gpa <= maxGPA;
                })
                .collect(Collectors.toList());
    }
    
    // Method to clear all data (useful for testing)
    public void clearAllStudents() {
        students.clear();
        studentsByRegNo.clear();
    }
}