package edu.ccrm.service;

import edu.ccrm.domain.Student;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Interface for Student Service operations - demonstrates abstraction
 */
public interface StudentService {
    Student createStudent(String id, String regNo, String fullName, String email, LocalDate dateOfBirth);
    Optional<Student> findStudentById(String id);
    Optional<Student> findStudentByRegNo(String regNo);
    List<Student> getAllStudents();
    List<Student> getActiveStudents();
    boolean updateStudent(Student student);
    boolean deactivateStudent(String id);
    boolean activateStudent(String id);
    boolean deleteStudent(String id);
    List<Student> searchStudentsByName(String namePattern);
    int getTotalStudentCount();
}