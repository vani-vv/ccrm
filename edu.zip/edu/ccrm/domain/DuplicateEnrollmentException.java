package edu.ccrm.domain;

/**
 * Custom checked exception for duplicate enrollment scenarios
 */
public class DuplicateEnrollmentException extends Exception {
    private String studentId;
    private String courseCode;
    
    public DuplicateEnrollmentException(String message) {
        super(message);
    }
    
    public DuplicateEnrollmentException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public DuplicateEnrollmentException(String studentId, String courseCode) {
        super(String.format("Student %s is already enrolled in course %s", studentId, courseCode));
        this.studentId = studentId;
        this.courseCode = courseCode;
    }
    
    public DuplicateEnrollmentException(String studentId, String courseCode, String message) {
        super(message);
        this.studentId = studentId;
        this.courseCode = courseCode;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getCourseCode() {
        return courseCode;
    }
}