package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.*;

/**
 * Instructor class extending Person - demonstrates inheritance
 */
public class Instructor extends Person {
    private String employeeId;
    private String department;
    private Set<String> assignedCourses; // Course codes
    private String qualification;
    private LocalDate joiningDate;
    
    // Constructor
    public Instructor(String id, String employeeId, String fullName, String email, 
                     LocalDate dateOfBirth, String department, String qualification) {
        super(id, fullName, email, dateOfBirth);
        this.employeeId = employeeId;
        this.department = department;
        this.qualification = qualification;
        this.assignedCourses = new HashSet<>();
        this.joiningDate = LocalDate.now();
    }
    
    // Implementation of abstract methods from Person
    @Override
    public String getRole() {
        return "INSTRUCTOR";
    }
    
    @Override
    public String getDisplayInfo() {
        return String.format("Instructor: %s (%s) - %s Department - %d courses assigned", 
                fullName, employeeId, department, assignedCourses.size());
    }
    
    // Instructor-specific methods
    public String getEmployeeId() {
        return employeeId;
    }
    
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    public Set<String> getAssignedCourses() {
        return new HashSet<>(assignedCourses); // Defensive copying
    }
    
    public void assignCourse(String courseCode) {
        assignedCourses.add(courseCode);
    }
    
    public void unassignCourse(String courseCode) {
        assignedCourses.remove(courseCode);
    }
    
    public boolean isAssignedTo(String courseCode) {
        return assignedCourses.contains(courseCode);
    }
    
    public String getQualification() {
        return qualification;
    }
    
    public void setQualification(String qualification) {
        this.qualification = qualification;
    }
    
    public LocalDate getJoiningDate() {
        return joiningDate;
    }
    
    public void setJoiningDate(LocalDate joiningDate) {
        this.joiningDate = joiningDate;
    }
    
    @Override
    public String toString() {
        return String.format("Instructor[id=%s, empId=%s, name=%s, dept=%s, courses=%d]",
                id, employeeId, fullName, department, assignedCourses.size());
    }
}