package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.*;

/**
 * Student class extending Person - demonstrates inheritance and encapsulation
 */
public class Student extends Person {
    private String regNo;
    private Set<String> enrolledCourses;  // Course codes
    private Map<String, Grade> grades;    // Course code -> Grade mapping
    private LocalDate enrollmentDate;
    private int maxCreditsPerSemester;
    
    // Constructor using super
    public Student(String id, String regNo, String fullName, String email, LocalDate dateOfBirth) {
        super(id, fullName, email, dateOfBirth);
        this.regNo = regNo;
        this.enrolledCourses = new HashSet<>();
        this.grades = new HashMap<>();
        this.enrollmentDate = LocalDate.now();
        this.maxCreditsPerSemester = 24; // Default max credits
    }
    
    // Implementation of abstract methods from Person
    @Override
    public String getRole() {
        return "STUDENT";
    }
    
    @Override
    public String getDisplayInfo() {
        return String.format("Student: %s (Reg: %s) - %d courses enrolled", 
                fullName, regNo, enrolledCourses.size());
    }
    
    // Student-specific methods
    public String getRegNo() {
        return regNo;
    }
    
    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }
    
    public Set<String> getEnrolledCourses() {
        return new HashSet<>(enrolledCourses); // Defensive copying
    }
    
    public boolean isEnrolledIn(String courseCode) {
        return enrolledCourses.contains(courseCode);
    }
    
    public void enrollInCourse(String courseCode) {
        enrolledCourses.add(courseCode);
    }
    
    public void unenrollFromCourse(String courseCode) {
        enrolledCourses.remove(courseCode);
        grades.remove(courseCode); // Remove grade if unenrolling
    }
    
    public Map<String, Grade> getGrades() {
        return new HashMap<>(grades); // Defensive copying
    }
    
    public void recordGrade(String courseCode, Grade grade) {
        if (enrolledCourses.contains(courseCode)) {
            grades.put(courseCode, grade);
        }
    }
    
    public Grade getGrade(String courseCode) {
        return grades.get(courseCode);
    }
    
    public double calculateGPA() {
        if (grades.isEmpty()) {
            return 0.0;
        }
        
        double totalGradePoints = grades.values().stream()
                .mapToDouble(Grade::getGradePoints)
                .sum();
        
        return totalGradePoints / grades.size();
    }
    
    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }
    
    public void setEnrollmentDate(LocalDate enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }
    
    public int getMaxCreditsPerSemester() {
        return maxCreditsPerSemester;
    }
    
    public void setMaxCreditsPerSemester(int maxCreditsPerSemester) {
        this.maxCreditsPerSemester = maxCreditsPerSemester;
    }
    
    // Method to get transcript info
    public String getTranscriptInfo() {
        StringBuilder transcript = new StringBuilder();
        transcript.append(String.format("TRANSCRIPT for %s (Reg: %s)\n", fullName, regNo));
        transcript.append("=".repeat(50)).append("\n");
        
        if (grades.isEmpty()) {
            transcript.append("No grades recorded yet.\n");
        } else {
            transcript.append("Course Code\tGrade\tGrade Points\n");
            transcript.append("-".repeat(40)).append("\n");
            for (Map.Entry<String, Grade> entry : grades.entrySet()) {
                Grade grade = entry.getValue();
                transcript.append(String.format("%s\t\t%s\t%.2f\n", 
                        entry.getKey(), grade.getLetter(), grade.getGradePoints()));
            }
            transcript.append("-".repeat(40)).append("\n");
            transcript.append(String.format("GPA: %.2f\n", calculateGPA()));
        }
        
        return transcript.toString();
    }
    
    @Override
    public String toString() {
        return String.format("Student[id=%s, regNo=%s, name=%s, courses=%d, GPA=%.2f]",
                id, regNo, fullName, enrolledCourses.size(), calculateGPA());
    }
}