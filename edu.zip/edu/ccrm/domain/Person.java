package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Abstract base class for all persons in the CCRM system
 * Demonstrates abstraction and inheritance
 */
public abstract class Person {
    protected String id;
    protected String fullName;
    protected String email;
    protected LocalDate dateOfBirth;
    protected boolean isActive;
    
    // Constructor
    public Person(String id, String fullName, String email, LocalDate dateOfBirth) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.isActive = true;
    }
    
    // Abstract methods - must be implemented by subclasses
    public abstract String getRole();
    public abstract String getDisplayInfo();
    
    // Concrete methods with encapsulation
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }
    
    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    // Method to deactivate person
    public void deactivate() {
        this.isActive = false;
    }
    
    // Method to activate person
    public void activate() {
        this.isActive = true;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return Objects.equals(id, person.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
    
    @Override
    public String toString() {
        return String.format("%s[id=%s, name=%s, email=%s, role=%s, active=%s]",
                getClass().getSimpleName(), id, fullName, email, getRole(), isActive);
    }
}