package edu.ccrm.domain;

import java.util.*;

/**
 * Course class with Builder pattern implementation
 */
public class Course {
    private final String code;           // Immutable after creation
    private final String title;         // Immutable after creation
    private final int credits;          // Immutable after creation
    private String instructorId;
    private Semester semester;
    private String department;
    private Set<String> enrolledStudents; // Student IDs
    private boolean isActive;
    private String description;
    private Set<String> prerequisites;   // Course codes that are prerequisites
    
    // Private constructor - only accessible through Builder
    private Course(Builder builder) {
        this.code = builder.code;
        this.title = builder.title;
        this.credits = builder.credits;
        this.instructorId = builder.instructorId;
        this.semester = builder.semester;
        this.department = builder.department;
        this.description = builder.description;
        this.prerequisites = new HashSet<>(builder.prerequisites);
        this.enrolledStudents = new HashSet<>();
        this.isActive = true;
    }
    
    // Getters
    public String getCode() {
        return code;
    }
    
    public String getTitle() {
        return title;
    }
    
    public int getCredits() {
        return credits;
    }
    
    public String getInstructorId() {
        return instructorId;
    }
    
    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    }
    
    public Semester getSemester() {
        return semester;
    }
    
    public void setSemester(Semester semester) {
        this.semester = semester;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    public Set<String> getEnrolledStudents() {
        return new HashSet<>(enrolledStudents); // Defensive copying
    }
    
    public void enrollStudent(String studentId) {
        enrolledStudents.add(studentId);
    }
    
    public void unenrollStudent(String studentId) {
        enrolledStudents.remove(studentId);
    }
    
    public boolean isStudentEnrolled(String studentId) {
        return enrolledStudents.contains(studentId);
    }
    
    public int getEnrollmentCount() {
        return enrolledStudents.size();
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Set<String> getPrerequisites() {
        return new HashSet<>(prerequisites); // Defensive copying
    }
    
    public void addPrerequisite(String courseCode) {
        prerequisites.add(courseCode);
    }
    
    public void removePrerequisite(String courseCode) {
        prerequisites.remove(courseCode);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return Objects.equals(code, course.code);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(code);
    }
    
    @Override
    public String toString() {
        return String.format("Course[code=%s, title=%s, credits=%d, dept=%s, semester=%s, enrolled=%d]",
                code, title, credits, department, semester, enrolledStudents.size());
    }
    
    // Builder Pattern Implementation - Static Nested Class
    public static class Builder {
        private String code;
        private String title;
        private int credits;
        private String instructorId;
        private Semester semester;
        private String department;
        private String description;
        private Set<String> prerequisites = new HashSet<>();
        
        public Builder(String code, String title, int credits) {
            this.code = code;
            this.title = title;
            this.credits = credits;
        }
        
        public Builder instructorId(String instructorId) {
            this.instructorId = instructorId;
            return this;
        }
        
        public Builder semester(Semester semester) {
            this.semester = semester;
            return this;
        }
        
        public Builder department(String department) {
            this.department = department;
            return this;
        }
        
        public Builder description(String description) {
            this.description = description;
            return this;
        }
        
        public Builder addPrerequisite(String courseCode) {
            this.prerequisites.add(courseCode);
            return this;
        }
        
        public Builder prerequisites(Set<String> prerequisites) {
            this.prerequisites = new HashSet<>(prerequisites);
            return this;
        }
        
        public Course build() {
            // Validation
            if (code == null || code.trim().isEmpty()) {
                throw new IllegalArgumentException("Course code cannot be null or empty");
            }
            if (title == null || title.trim().isEmpty()) {
                throw new IllegalArgumentException("Course title cannot be null or empty");
            }
            if (credits <= 0) {
                throw new IllegalArgumentException("Credits must be positive");
            }
            
            return new Course(this);
        }
    }
}