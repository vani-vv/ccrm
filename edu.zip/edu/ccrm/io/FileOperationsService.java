package edu.ccrm.io;

import edu.ccrm.domain.*;
import edu.ccrm.service.*;
import edu.ccrm.config.AppConfig;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Stream;

/**
 * Service for file I/O operations using NIO.2 APIs
 */
public class FileOperationsService {
    private final StudentService studentService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    private final AppConfig config;
    
    public FileOperationsService(StudentService studentService, CourseService courseService, 
                               EnrollmentService enrollmentService) {
        this.studentService = studentService;
        this.courseService = courseService;
        this.enrollmentService = enrollmentService;
        this.config = AppConfig.getInstance();
    }
    
    /**
     * Import students from CSV file using NIO.2
     */
    public void importStudentsFromCSV(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            throw new FileNotFoundException("File not found: " + filePath);
        }
        
        try (Stream<String> lines = Files.lines(path)) {
            lines.skip(1) // Skip header
                 .forEach(line -> {
                     try {
                         String[] parts = line.split(",");
                         if (parts.length >= 5) {
                             String id = parts[0].trim();
                             String regNo = parts[1].trim();
                             String name = parts[2].trim();
                             String email = parts[3].trim();
                             LocalDate dob = LocalDate.parse(parts[4].trim());
                             
                             studentService.createStudent(id, regNo, name, email, dob);
                         }
                     } catch (Exception e) {
                         System.err.println("Error importing student: " + line + " - " + e.getMessage());
                     }
                 });
        }
    }
    
    /**
     * Import courses from CSV file
     */
    public void importCoursesFromCSV(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            throw new FileNotFoundException("File not found: " + filePath);
        }
        
        try (Stream<String> lines = Files.lines(path)) {
            lines.skip(1) // Skip header
                 .forEach(line -> {
                     try {
                         String[] parts = line.split(",");
                         if (parts.length >= 6) {
                             String code = parts[0].trim();
                             String title = parts[1].trim();
                             int credits = Integer.parseInt(parts[2].trim());
                             String instructorId = parts[3].trim();
                             Semester semester = Semester.fromCode(parts[4].trim());
                             String department = parts[5].trim();
                             
                             courseService.createCourse(code, title, credits, instructorId, semester, department);
                         }
                     } catch (Exception e) {
                         System.err.println("Error importing course: " + line + " - " + e.getMessage());
                     }
                 });
        }
    }
    
    /**
     * Export students to CSV file using NIO.2
     */
    public void exportStudentsToCSV(String fileName) throws IOException {
        Path exportDir = config.getExportPath();
        Files.createDirectories(exportDir);
        
        Path filePath = exportDir.resolve(fileName);
        
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardOpenOption.CREATE, 
                                                            StandardOpenOption.TRUNCATE_EXISTING)) {
            // Write header
            writer.write("ID,RegNo,FullName,Email,DateOfBirth,EnrollmentDate,IsActive,EnrolledCourses,GPA");
            writer.newLine();
            
            // Write student data
            for (Student student : studentService.getAllStudents()) {
                writer.write(String.format("%s,%s,%s,%s,%s,%s,%s,\"%s\",%.2f",
                    student.getId(),
                    student.getRegNo(),
                    student.getFullName(),
                    student.getEmail(),
                    student.getDateOfBirth().toString(),
                    student.getEnrollmentDate().toString(),
                    student.isActive(),
                    String.join(";", student.getEnrolledCourses()),
                    student.calculateGPA()
                ));
                writer.newLine();
            }
        }
        
        System.out.println("Students exported to: " + filePath.toAbsolutePath());
    }
    
    /**
     * Export courses to CSV file
     */
    public void exportCoursesToCSV(String fileName) throws IOException {
        Path exportDir = config.getExportPath();
        Files.createDirectories(exportDir);
        
        Path filePath = exportDir.resolve(fileName);
        
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardOpenOption.CREATE,
                                                            StandardOpenOption.TRUNCATE_EXISTING)) {
            // Write header
            writer.write("Code,Title,Credits,InstructorId,Semester,Department,IsActive,EnrollmentCount");
            writer.newLine();
            
            // Write course data
            for (Course course : courseService.getAllCourses()) {
                writer.write(String.format("%s,%s,%d,%s,%s,%s,%s,%d",
                    course.getCode(),
                    course.getTitle(),
                    course.getCredits(),
                    course.getInstructorId() != null ? course.getInstructorId() : "",
                    course.getSemester() != null ? course.getSemester().getCode() : "",
                    course.getDepartment() != null ? course.getDepartment() : "",
                    course.isActive(),
                    course.getEnrollmentCount()
                ));
                writer.newLine();
            }
        }
        
        System.out.println("Courses exported to: " + filePath.toAbsolutePath());
    }
    
    /**
     * Export enrollments to CSV file
     */
    public void exportEnrollmentsToCSV(String fileName) throws IOException {
        Path exportDir = config.getExportPath();
        Files.createDirectories(exportDir);
        
        Path filePath = exportDir.resolve(fileName);
        
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardOpenOption.CREATE,
                                                            StandardOpenOption.TRUNCATE_EXISTING)) {
            // Write header
            writer.write("EnrollmentId,StudentId,CourseCode,Semester,EnrollmentDate,Grade,Marks,IsActive");
            writer.newLine();
            
            // Write enrollment data
            for (Enrollment enrollment : enrollmentService.getAllActiveEnrollments()) {
                writer.write(String.format("%s,%s,%s,%s,%s,%s,%.2f,%s",
                    enrollment.getEnrollmentId(),
                    enrollment.getStudentId(),
                    enrollment.getCourseCode(),
                    enrollment.getSemester(),
                    enrollment.getEnrollmentDate().toString(),
                    enrollment.getGrade() != null ? enrollment.getGrade().getLetter() : "",
                    enrollment.getMarks(),
                    enrollment.isActive()
                ));
                writer.newLine();
            }
        }
        
        System.out.println("Enrollments exported to: " + filePath.toAbsolutePath());
    }
    
    /**
     * Backup all data with timestamp using NIO.2
     */
    public void backupAllData() throws IOException {
        String timestamp = LocalDateTime.now().format(config.getTimestampFormatter());
        String backupFolderName = "backup_" + timestamp;
        
        Path backupDir = config.getBackupPath().resolve(backupFolderName);
        Files.createDirectories(backupDir);
        
        // Export all data to backup folder
        exportStudentsToCSV(backupFolderName + "/students.csv");
        exportCoursesToCSV(backupFolderName + "/courses.csv");
        exportEnrollmentsToCSV(backupFolderName + "/enrollments.csv");
        
        // Copy exported files to backup directory
        Path exportDir = config.getExportPath();
        if (Files.exists(exportDir)) {
            try (Stream<Path> files = Files.walk(exportDir, 1)) {
                files.filter(Files::isRegularFile)
                     .forEach(file -> {
                         try {
                             Path target = backupDir.resolve(file.getFileName());
                             Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING);
                         } catch (IOException e) {
                             System.err.println("Error copying file: " + e.getMessage());
                         }
                     });
            }
        }
        
        System.out.println("Backup created: " + backupDir.toAbsolutePath());
    }
    
    /**
     * Recursively calculate total size of backup directory
     */
    public long calculateBackupSize() throws IOException {
        Path backupDir = config.getBackupPath();
        if (!Files.exists(backupDir)) {
            return 0;
        }
        
        try (Stream<Path> paths = Files.walk(backupDir)) {
            return paths
                .filter(Files::isRegularFile)
                .mapToLong(path -> {
                    try {
                        return Files.size(path);
                    } catch (IOException e) {
                        return 0;
                    }
                })
                .sum();
        }
    }
    
    /**
     * Recursively list all backup files with depth
     */
    public void listBackupFiles(int maxDepth) throws IOException {
        Path backupDir = config.getBackupPath();
        if (!Files.exists(backupDir)) {
            System.out.println("No backup directory found.");
            return;
        }
        
        try (Stream<Path> paths = Files.walk(backupDir, maxDepth)) {
            paths.forEach(path -> {
                int depth = path.getNameCount() - backupDir.getNameCount();
                String indent = "  ".repeat(depth);
                
                if (Files.isDirectory(path)) {
                    System.out.println(indent + "[DIR] " + path.getFileName());
                } else {
                    try {
                        long size = Files.size(path);
                        System.out.println(indent + "[FILE] " + path.getFileName() + " (" + size + " bytes)");
                    } catch (IOException e) {
                        System.out.println(indent + "[FILE] " + path.getFileName() + " (size unknown)");
                    }
                }
            });
        }
    }
}