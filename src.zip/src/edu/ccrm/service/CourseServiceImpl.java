package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Semester;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Implementation of CourseService with Stream API demonstrations
 */
public class CourseServiceImpl implements CourseService {
    private Map<String, Course> courses; // Course code -> Course mapping
    
    public CourseServiceImpl() {
        this.courses = new HashMap<>();
    }
    
    @Override
    public Course createCourse(String code, String title, int credits, String instructorId, 
                              Semester semester, String department) {
        if (courses.containsKey(code)) {
            throw new IllegalArgumentException("Course with code " + code + " already exists");
        }
        
        Course course = new Course.Builder(code, title, credits)
                .instructorId(instructorId)
                .semester(semester)
                .department(department)
                .build();
                
        courses.put(code, course);
        return course;
    }
    
    @Override
    public Optional<Course> findCourseByCode(String code) {
        return Optional.ofNullable(courses.get(code));
    }
    
    @Override
    public List<Course> getAllCourses() {
        return new ArrayList<>(courses.values());
    }
    
    @Override
    public List<Course> getActiveCourses() {
        return courses.values().stream()
                .filter(Course::isActive)
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Course> getCoursesByInstructor(String instructorId) {
        // Using Stream API with lambda expressions
        return courses.values().stream()
                .filter(course -> Objects.equals(course.getInstructorId(), instructorId))
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Course> getCoursesByDepartment(String department) {
        return courses.values().stream()
                .filter(course -> Objects.equals(course.getDepartment(), department))
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Course> getCoursesBySemester(Semester semester) {
        return courses.values().stream()
                .filter(course -> Objects.equals(course.getSemester(), semester))
                .collect(Collectors.toList());
    }
    
    @Override
    public boolean updateCourse(Course course) {
        if (courses.containsKey(course.getCode())) {
            courses.put(course.getCode(), course);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean deactivateCourse(String code) {
        Course course = courses.get(code);
        if (course != null) {
            course.setActive(false);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean activateCourse(String code) {
        Course course = courses.get(code);
        if (course != null) {
            course.setActive(true);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean deleteCourse(String code) {
        return courses.remove(code) != null;
    }
    
    @Override
    public List<Course> searchCoursesByTitle(String titlePattern) {
        String pattern = titlePattern.toLowerCase();
        return courses.values().stream()
                .filter(course -> course.getTitle().toLowerCase().contains(pattern))
                .collect(Collectors.toList());
    }
    
    @Override
    public int getTotalCourseCount() {
        return courses.size();
    }
    
    // Additional utility methods using Stream API
    public Map<String, Long> getCourseCountByDepartment() {
        return courses.values().stream()
                .collect(Collectors.groupingBy(
                        Course::getDepartment, 
                        Collectors.counting()));
    }
    
    public Map<Semester, Long> getCourseCountBySemester() {
        return courses.values().stream()
                .filter(course -> course.getSemester() != null)
                .collect(Collectors.groupingBy(
                        Course::getSemester, 
                        Collectors.counting()));
    }
    
    public double getAverageEnrollmentCount() {
        return courses.values().stream()
                .mapToInt(Course::getEnrollmentCount)
                .average()
                .orElse(0.0);
    }
    
    public List<Course> getCoursesWithHighEnrollment(int threshold) {
        return courses.values().stream()
                .filter(course -> course.getEnrollmentCount() > threshold)
                .sorted((c1, c2) -> Integer.compare(c2.getEnrollmentCount(), c1.getEnrollmentCount()))
                .collect(Collectors.toList());
    }
    
    // Method to clear all data
    public void clearAllCourses() {
        courses.clear();
    }
}