package edu.ccrm.service;

import edu.ccrm.domain.Enrollment;
import edu.ccrm.domain.Grade;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Implementation of EnrollmentService
 */
public class EnrollmentServiceImpl implements EnrollmentService {
    private Map<String, Enrollment> enrollments; // enrollmentId -> Enrollment
    private StudentService studentService;
    private CourseService courseService;
    private int nextEnrollmentId;
    
    public EnrollmentServiceImpl(StudentService studentService, CourseService courseService) {
        this.enrollments = new HashMap<>();
        this.studentService = studentService;
        this.courseService = courseService;
        this.nextEnrollmentId = 1;
    }
    
    @Override
    public Enrollment enrollStudent(String studentId, String courseCode, String semester) {
        // Check if student and course exist
        if (!studentService.findStudentById(studentId).isPresent()) {
            throw new IllegalArgumentException("Student with ID " + studentId + " not found");
        }
        if (!courseService.findCourseByCode(courseCode).isPresent()) {
            throw new IllegalArgumentException("Course with code " + courseCode + " not found");
        }
        
        // Check if already enrolled
        if (findEnrollment(studentId, courseCode).isPresent()) {
            throw new IllegalArgumentException("Student is already enrolled in this course");
        }
        
        // Create enrollment
        String enrollmentId = "ENR" + String.format("%06d", nextEnrollmentId++);
        Enrollment enrollment = new Enrollment(enrollmentId, studentId, courseCode, semester);
        
        enrollments.put(enrollmentId, enrollment);
        
        // Update student and course records
        studentService.findStudentById(studentId).ifPresent(student -> 
            student.enrollInCourse(courseCode));
        courseService.findCourseByCode(courseCode).ifPresent(course -> 
            course.enrollStudent(studentId));
        
        return enrollment;
    }
    
    @Override
    public boolean unenrollStudent(String studentId, String courseCode) {
        Optional<Enrollment> enrollmentOpt = findEnrollment(studentId, courseCode);
        if (enrollmentOpt.isPresent()) {
            Enrollment enrollment = enrollmentOpt.get();
            enrollment.unenroll();
            
            // Update student and course records
            studentService.findStudentById(studentId).ifPresent(student -> 
                student.unenrollFromCourse(courseCode));
            courseService.findCourseByCode(courseCode).ifPresent(course -> 
                course.unenrollStudent(studentId));
            
            return true;
        }
        return false;
    }
    
    @Override
    public Optional<Enrollment> findEnrollment(String studentId, String courseCode) {
        return enrollments.values().stream()
                .filter(enrollment -> enrollment.getStudentId().equals(studentId) && 
                                    enrollment.getCourseCode().equals(courseCode) &&
                                    enrollment.isActive())
                .findFirst();
    }
    
    @Override
    public List<Enrollment> getEnrollmentsByStudent(String studentId) {
        return enrollments.values().stream()
                .filter(enrollment -> enrollment.getStudentId().equals(studentId))
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Enrollment> getEnrollmentsByCourse(String courseCode) {
        return enrollments.values().stream()
                .filter(enrollment -> enrollment.getCourseCode().equals(courseCode))
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Enrollment> getAllActiveEnrollments() {
        return enrollments.values().stream()
                .filter(Enrollment::isActive)
                .collect(Collectors.toList());
    }
    
    @Override
    public boolean recordGrade(String studentId, String courseCode, Grade grade) {
        Optional<Enrollment> enrollmentOpt = findEnrollment(studentId, courseCode);
        if (enrollmentOpt.isPresent()) {
            Enrollment enrollment = enrollmentOpt.get();
            enrollment.setGrade(grade);
            
            // Also update student's grade record
            studentService.findStudentById(studentId).ifPresent(student -> 
                student.recordGrade(courseCode, grade));
            
            return true;
        }
        return false;
    }
    
    @Override
    public boolean recordMarks(String studentId, String courseCode, double marks) {
        Optional<Enrollment> enrollmentOpt = findEnrollment(studentId, courseCode);
        if (enrollmentOpt.isPresent()) {
            Enrollment enrollment = enrollmentOpt.get();
            enrollment.setMarks(marks);
            
            // Also update student's grade record
            studentService.findStudentById(studentId).ifPresent(student -> 
                student.recordGrade(courseCode, enrollment.getGrade()));
            
            return true;
        }
        return false;
    }
    
    @Override
    public boolean canEnrollStudent(String studentId, String courseCode) {
        // Check if student exists and is active
        Optional<edu.ccrm.domain.Student> studentOpt = studentService.findStudentById(studentId);
        if (!studentOpt.isPresent() || !studentOpt.get().isActive()) {
            return false;
        }
        
        // Check if course exists and is active
        Optional<edu.ccrm.domain.Course> courseOpt = courseService.findCourseByCode(courseCode);
        if (!courseOpt.isPresent() || !courseOpt.get().isActive()) {
            return false;
        }
        
        // Check if already enrolled
        if (findEnrollment(studentId, courseCode).isPresent()) {
            return false;
        }
        
        return true;
    }
    
    @Override
    public int getEnrollmentCount() {
        return (int) enrollments.values().stream()
                .filter(Enrollment::isActive)
                .count();
    }
    
    // Additional utility methods
    public Map<String, Long> getEnrollmentCountBySemester() {
        return enrollments.values().stream()
                .filter(Enrollment::isActive)
                .collect(Collectors.groupingBy(
                        Enrollment::getSemester,
                        Collectors.counting()));
    }
    
    public List<Enrollment> getEnrollmentsWithGrades() {
        return enrollments.values().stream()
                .filter(enrollment -> enrollment.hasGrade() && enrollment.isActive())
                .collect(Collectors.toList());
    }
    
    public double getAverageMarks() {
        return enrollments.values().stream()
                .filter(enrollment -> enrollment.hasMarks() && enrollment.isActive())
                .mapToDouble(Enrollment::getMarks)
                .average()
                .orElse(0.0);
    }
    
    public void clearAllEnrollments() {
        enrollments.clear();
        nextEnrollmentId = 1;
    }
}