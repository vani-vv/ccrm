package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Enrollment class representing the relationship between Student and Course
 */
public class Enrollment {
    private String enrollmentId;
    private String studentId;
    private String courseCode;
    private LocalDate enrollmentDate;
    private LocalDate unenrollmentDate;
    private boolean isActive;
    private Grade grade;
    private double marks;
    private String semester; // Academic semester when enrolled
    
    // Constructor
    public Enrollment(String enrollmentId, String studentId, String courseCode, String semester) {
        this.enrollmentId = enrollmentId;
        this.studentId = studentId;
        this.courseCode = courseCode;
        this.semester = semester;
        this.enrollmentDate = LocalDate.now();
        this.isActive = true;
        this.marks = -1; // -1 indicates no marks assigned yet
    }
    
    // Getters and Setters
    public String getEnrollmentId() {
        return enrollmentId;
    }
    
    public void setEnrollmentId(String enrollmentId) {
        this.enrollmentId = enrollmentId;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public String getCourseCode() {
        return courseCode;
    }
    
    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }
    
    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }
    
    public void setEnrollmentDate(LocalDate enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }
    
    public LocalDate getUnenrollmentDate() {
        return unenrollmentDate;
    }
    
    public void setUnenrollmentDate(LocalDate unenrollmentDate) {
        this.unenrollmentDate = unenrollmentDate;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        this.isActive = active;
        if (!active && unenrollmentDate == null) {
            this.unenrollmentDate = LocalDate.now();
        }
    }
    
    public Grade getGrade() {
        return grade;
    }
    
    public void setGrade(Grade grade) {
        this.grade = grade;
    }
    
    public double getMarks() {
        return marks;
    }
    
    public void setMarks(double marks) {
        this.marks = marks;
        // Automatically calculate grade from marks
        if (marks >= 0) {
            this.grade = Grade.fromMarks(marks);
        }
    }
    
    public String getSemester() {
        return semester;
    }
    
    public void setSemester(String semester) {
        this.semester = semester;
    }
    
    // Business methods
    public void unenroll() {
        setActive(false);
    }
    
    public void recordMarks(double marks) {
        setMarks(marks);
    }
    
    public boolean hasGrade() {
        return grade != null;
    }
    
    public boolean hasMarks() {
        return marks >= 0;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Enrollment that = (Enrollment) o;
        return Objects.equals(enrollmentId, that.enrollmentId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(enrollmentId);
    }
    
    @Override
    public String toString() {
        return String.format("Enrollment[id=%s, student=%s, course=%s, semester=%s, grade=%s, active=%s]",
                enrollmentId, studentId, courseCode, semester, 
                grade != null ? grade.getLetter() : "N/A", isActive);
    }
}