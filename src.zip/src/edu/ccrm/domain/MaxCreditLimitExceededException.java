package edu.ccrm.domain;

/**
 * Custom unchecked exception for credit limit violations
 */
public class MaxCreditLimitExceededException extends RuntimeException {
    private String studentId;
    private int currentCredits;
    private int maxCredits;
    private int attemptedCredits;
    
    public MaxCreditLimitExceededException(String message) {
        super(message);
    }
    
    public MaxCreditLimitExceededException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public MaxCreditLimitExceededException(String studentId, int currentCredits, 
                                         int maxCredits, int attemptedCredits) {
        super(String.format("Student %s cannot enroll. Current credits: %d, Max allowed: %d, Attempted: %d", 
                studentId, currentCredits, maxCredits, attemptedCredits));
        this.studentId = studentId;
        this.currentCredits = currentCredits;
        this.maxCredits = maxCredits;
        this.attemptedCredits = attemptedCredits;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public int getCurrentCredits() {
        return currentCredits;
    }
    
    public int getMaxCredits() {
        return maxCredits;
    }
    
    public int getAttemptedCredits() {
        return attemptedCredits;
    }
}