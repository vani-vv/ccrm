package edu.ccrm.domain;

/**
 * Enum representing academic semesters with code and display name
 */
public enum Semester {
    SPRING("SP", "Spring"),
    SUMMER("SU", "Summer"), 
    FALL("FA", "Fall"),
    WINTER("WI", "Winter");
    
    private final String code;
    private final String displayName;
    
    // Constructor for enum
    Semester(String code, String displayName) {
        this.code = code;
        this.displayName = displayName;
    }
    
    // Getters
    public String getCode() {
        return code;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    @Override
    public String toString() {
        return displayName + " (" + code + ")";
    }
    
    // Static method to find semester by code
    public static Semester fromCode(String code) {
        for (Semester semester : values()) {
            if (semester.getCode().equalsIgnoreCase(code)) {
                return semester;
            }
        }
        throw new IllegalArgumentException("No semester found with code: " + code);
    }
}