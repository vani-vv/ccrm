package edu.ccrm.cli;

import edu.ccrm.config.AppConfig;
import edu.ccrm.domain.*;
import edu.ccrm.service.*;
import edu.ccrm.io.FileOperationsService;
import edu.ccrm.util.ValidationUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Console-based CLI for CCRM application
 * Demonstrates switch statements, loops, and user interaction
 */
public class CCRMConsole {
    private final Scanner scanner;
    private final AppConfig config;
    private final StudentService studentService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    private final FileOperationsService fileService;
    private boolean running;
    
    public CCRMConsole() {
        this.scanner = new Scanner(System.in);
        this.config = AppConfig.getInstance();
        this.studentService = new StudentServiceImpl();
        this.courseService = new CourseServiceImpl();
        this.enrollmentService = new EnrollmentServiceImpl(studentService, courseService);
        this.fileService = new FileOperationsService(studentService, courseService, enrollmentService);
        this.running = true;
        
        // Initialize with some sample data
        initializeSampleData();
    }
    
    /**
     * Main menu loop with enhanced switch statement
     */
    public void start() {
        config.printBanner();
        System.out.println("Welcome to the Campus Course & Records Manager!");
        System.out.println();
        
        while (running) {
            try {
                displayMainMenu();
                int choice = getIntInput("Enter your choice: ");
                
                // Enhanced switch statement (Java 14+ style)
                switch (choice) {
                    case 1 -> manageStudents();
                    case 2 -> manageCourses();
                    case 3 -> manageEnrollments();
                    case 4 -> manageGrades();
                    case 5 -> generateReports();
                    case 6 -> fileOperations();
                    case 7 -> backupOperations();
                    case 8 -> showPlatformInfo();
                    case 9 -> {
                        System.out.println("Thank you for using CCRM!");
                        running = false;
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.err.println("An error occurred: " + e.getMessage());
                System.out.println("Please try again.");
            }
            
            if (running) {
                System.out.println("\nPress Enter to continue...");
                try {
                    if (scanner.hasNextLine()) {
                        scanner.nextLine();
                    } else {
                        System.out.println("No input available. Exiting application...");
                        running = false;
                    }
                } catch (Exception e) {
                    System.out.println("Input error. Exiting application...");
                    running = false;
                }
            }
        }
    }
    
    private void displayMainMenu() {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("MAIN MENU");
        System.out.println("=".repeat(50));
        System.out.println("1. Manage Students");
        System.out.println("2. Manage Courses");
        System.out.println("3. Manage Enrollments");
        System.out.println("4. Manage Grades");
        System.out.println("5. Generate Reports");
        System.out.println("6. File Operations (Import/Export)");
        System.out.println("7. Backup & Archive");
        System.out.println("8. Show Platform Information");
        System.out.println("9. Exit");
        System.out.println("=".repeat(50));
    }
    
    private void manageStudents() {
        boolean back = false;
        while (!back) {
            System.out.println("\nSTUDENT MANAGEMENT");
            System.out.println("1. Add New Student");
            System.out.println("2. List All Students");
            System.out.println("3. Search Students");
            System.out.println("4. View Student Profile");
            System.out.println("5. Update Student");
            System.out.println("6. Deactivate Student");
            System.out.println("7. Back to Main Menu");
            
            int choice = getIntInput("Choose an option: ");
            
            switch (choice) {
                case 1:
                    addNewStudent();
                    break;
                case 2:
                    listAllStudents();
                    break;
                case 3:
                    searchStudents();
                    break;
                case 4:
                    viewStudentProfile();
                    break;
                case 5:
                    updateStudent();
                    break;
                case 6:
                    deactivateStudent();
                    break;
                case 7:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    private void manageCourses() {
        boolean back = false;
        while (!back) {
            System.out.println("\nCOURSE MANAGEMENT");
            System.out.println("1. Add New Course");
            System.out.println("2. List All Courses");
            System.out.println("3. Search Courses");
            System.out.println("4. Filter by Department");
            System.out.println("5. Filter by Instructor");
            System.out.println("6. Update Course");
            System.out.println("7. Back to Main Menu");
            
            int choice = getIntInput("Choose an option: ");
            
            switch (choice) {
                case 1:
                    addNewCourse();
                    break;
                case 2:
                    listAllCourses();
                    break;
                case 3:
                    searchCourses();
                    break;
                case 4:
                    filterCoursesByDepartment();
                    break;
                case 5:
                    filterCoursesByInstructor();
                    break;
                case 6:
                    updateCourse();
                    break;
                case 7:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    private void manageEnrollments() {
        boolean back = false;
        while (!back) {
            System.out.println("\nENROLLMENT MANAGEMENT");
            System.out.println("1. Enroll Student in Course");
            System.out.println("2. Unenroll Student from Course");
            System.out.println("3. View Student Enrollments");
            System.out.println("4. View Course Enrollments");
            System.out.println("5. List All Active Enrollments");
            System.out.println("6. Back to Main Menu");
            
            int choice = getIntInput("Choose an option: ");
            
            switch (choice) {
                case 1:
                    enrollStudent();
                    break;
                case 2:
                    unenrollStudent();
                    break;
                case 3:
                    viewStudentEnrollments();
                    break;
                case 4:
                    viewCourseEnrollments();
                    break;
                case 5:
                    listAllEnrollments();
                    break;
                case 6:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    private void manageGrades() {
        boolean back = false;
        while (!back) {
            System.out.println("\nGRADE MANAGEMENT");
            System.out.println("1. Record Marks for Student");
            System.out.println("2. Assign Grade to Student");
            System.out.println("3. View Student Transcript");
            System.out.println("4. Calculate Student GPA");
            System.out.println("5. Back to Main Menu");
            
            int choice = getIntInput("Choose an option: ");
            
            switch (choice) {
                case 1:
                    recordMarks();
                    break;
                case 2:
                    assignGrade();
                    break;
                case 3:
                    viewTranscript();
                    break;
                case 4:
                    calculateGPA();
                    break;
                case 5:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    private void generateReports() {
        boolean back = false;
        while (!back) {
            System.out.println("\nREPORT GENERATION");
            System.out.println("1. Student Statistics");
            System.out.println("2. Course Statistics");
            System.out.println("3. GPA Distribution Report");
            System.out.println("4. Department-wise Course Count");
            System.out.println("5. Top Performing Students");
            System.out.println("6. Back to Main Menu");
            
            int choice = getIntInput("Choose an option: ");
            
            switch (choice) {
                case 1:
                    generateStudentStatistics();
                    break;
                case 2:
                    generateCourseStatistics();
                    break;
                case 3:
                    generateGPADistribution();
                    break;
                case 4:
                    generateDepartmentReport();
                    break;
                case 5:
                    generateTopStudentsReport();
                    break;
                case 6:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    private void fileOperations() {
        boolean back = false;
        while (!back) {
            System.out.println("\nFILE OPERATIONS");
            System.out.println("1. Import Students from CSV");
            System.out.println("2. Import Courses from CSV");
            System.out.println("3. Export Students to CSV");
            System.out.println("4. Export Courses to CSV");
            System.out.println("5. Export Enrollments to CSV");
            System.out.println("6. Back to Main Menu");
            
            int choice = getIntInput("Choose an option: ");
            
            switch (choice) {
                case 1:
                    importStudentsFromFile();
                    break;
                case 2:
                    importCoursesFromFile();
                    break;
                case 3:
                    exportStudentsToFile();
                    break;
                case 4:
                    exportCoursesToFile();
                    break;
                case 5:
                    exportEnrollmentsToFile();
                    break;
                case 6:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    private void backupOperations() {
        boolean back = false;
        while (!back) {
            System.out.println("\nBACKUP OPERATIONS");
            System.out.println("1. Create Backup");
            System.out.println("2. Show Backup Size");
            System.out.println("3. List Backup Files");
            System.out.println("4. Back to Main Menu");
            
            int choice = getIntInput("Choose an option: ");
            
            switch (choice) {
                case 1:
                    createBackup();
                    break;
                case 2:
                    showBackupSize();
                    break;
                case 3:
                    listBackupFiles();
                    break;
                case 4:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    // Implementation methods for various operations
    private void addNewStudent() {
        System.out.println("\nADD NEW STUDENT");
        try {
            String id = getStringInput("Enter Student ID: ");
            String regNo = getStringInput("Enter Registration Number: ");
            String name = getStringInput("Enter Full Name: ");
            String email = getStringInput("Enter Email: ");
            System.out.println("Enter Date of Birth (YYYY-MM-DD): ");
            LocalDate dob = LocalDate.parse(scanner.nextLine());
            
            Student student = studentService.createStudent(id, regNo, name, email, dob);
            System.out.println("Student created successfully: " + student);
        } catch (Exception e) {
            System.err.println("Error creating student: " + e.getMessage());
        }
    }
    
    private void listAllStudents() {
        System.out.println("\nALL STUDENTS");
        System.out.println("-".repeat(50));
        List<Student> students = studentService.getAllStudents();
        
        if (students.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        
        for (Student student : students) {
            System.out.println(student.getDisplayInfo());
        }
        System.out.println("\nTotal students: " + students.size());
    }
    
    private void addNewCourse() {
        System.out.println("\nADD NEW COURSE");
        try {
            String code = getStringInput("Enter Course Code: ");
            String title = getStringInput("Enter Course Title: ");
            int credits = getIntInput("Enter Credits: ");
            String instructorId = getStringInput("Enter Instructor ID: ");
            
            System.out.println("Select Semester:");
            for (int i = 0; i < Semester.values().length; i++) {
                System.out.println((i + 1) + ". " + Semester.values()[i]);
            }
            int semesterChoice = getIntInput("Choose semester: ") - 1;
            Semester semester = Semester.values()[semesterChoice];
            
            String department = getStringInput("Enter Department: ");
            
            Course course = courseService.createCourse(code, title, credits, instructorId, semester, department);
            System.out.println("Course created successfully: " + course);
        } catch (Exception e) {
            System.err.println("Error creating course: " + e.getMessage());
        }
    }
    
    private void listAllCourses() {
        System.out.println("\nALL COURSES");
        System.out.println("-".repeat(50));
        List<Course> courses = courseService.getAllCourses();
        
        if (courses.isEmpty()) {
            System.out.println("No courses found.");
            return;
        }
        
        for (Course course : courses) {
            System.out.printf("%-8s | %-30s | %d credits | %s | %s%n",
                course.getCode(), course.getTitle(), course.getCredits(),
                course.getDepartment(), course.getSemester());
        }
        System.out.println("\nTotal courses: " + courses.size());
    }
    
    private void enrollStudent() {
        System.out.println("\nENROLL STUDENT");
        try {
            String studentId = getStringInput("Enter Student ID: ");
            String courseCode = getStringInput("Enter Course Code: ");
            String semester = getStringInput("Enter Semester (e.g., Fall2024): ");
            
            Enrollment enrollment = enrollmentService.enrollStudent(studentId, courseCode, semester);
            System.out.println("Student enrolled successfully: " + enrollment);
        } catch (Exception e) {
            System.err.println("Error enrolling student: " + e.getMessage());
        }
    }
    
    private void viewTranscript() {
        System.out.println("\nVIEW TRANSCRIPT");
        String studentId = getStringInput("Enter Student ID: ");
        
        Optional<Student> studentOpt = studentService.findStudentById(studentId);
        if (studentOpt.isPresent()) {
            Student student = studentOpt.get();
            System.out.println("\n" + student.getTranscriptInfo());
        } else {
            System.out.println("Student not found.");
        }
    }
    
    private void createBackup() {
        System.out.println("\nCREATING BACKUP...");
        try {
            fileService.backupAllData();
            System.out.println("Backup created successfully!");
        } catch (Exception e) {
            System.err.println("Error creating backup: " + e.getMessage());
        }
    }
    
    private void showBackupSize() {
        try {
            long size = fileService.calculateBackupSize();
            System.out.printf("Total backup size: %d bytes (%.2f MB)%n", size, size / 1024.0 / 1024.0);
        } catch (Exception e) {
            System.err.println("Error calculating backup size: " + e.getMessage());
        }
    }
    
    private void showPlatformInfo() {
        System.out.println(config.getJavaPlatformInfo());
    }
    
    // Utility methods for input handling with graceful EOF handling
    private String getStringInput(String prompt) {
        System.out.print(prompt);
        try {
            if (scanner.hasNextLine()) {
                return scanner.nextLine().trim();
            } else {
                System.out.println("\nNo input available. Running demo mode...");
                runDemoMode();
                running = false;
                return "";
            }
        } catch (Exception e) {
            System.out.println("\nInput error. Running demo mode...");
            runDemoMode();
            running = false;
            return "";
        }
    }
    
    private int getIntInput(String prompt) {
        while (running) {
            try {
                System.out.print(prompt);
                if (scanner.hasNextLine()) {
                    String input = scanner.nextLine().trim();
                    return Integer.parseInt(input);
                } else {
                    System.out.println("\nNo input available. Running demo mode...");
                    runDemoMode();
                    running = false;
                    return -1;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            } catch (Exception e) {
                System.out.println("\nInput error. Running demo mode...");
                runDemoMode();
                running = false;
                return -1;
            }
        }
        return -1;
    }
    
    // Placeholder methods for other operations (abbreviated for space)
    private void searchStudents() { System.out.println("Search functionality - to be implemented"); }
    private void viewStudentProfile() { System.out.println("View profile - to be implemented"); }
    private void updateStudent() { System.out.println("Update student - to be implemented"); }
    private void deactivateStudent() { System.out.println("Deactivate student - to be implemented"); }
    private void searchCourses() { System.out.println("Search courses - to be implemented"); }
    private void filterCoursesByDepartment() { System.out.println("Filter by department - to be implemented"); }
    private void filterCoursesByInstructor() { System.out.println("Filter by instructor - to be implemented"); }
    private void updateCourse() { System.out.println("Update course - to be implemented"); }
    private void unenrollStudent() { System.out.println("Unenroll student - to be implemented"); }
    private void viewStudentEnrollments() { System.out.println("View student enrollments - to be implemented"); }
    private void viewCourseEnrollments() { System.out.println("View course enrollments - to be implemented"); }
    private void listAllEnrollments() { System.out.println("List enrollments - to be implemented"); }
    private void recordMarks() { System.out.println("Record marks - to be implemented"); }
    private void assignGrade() { System.out.println("Assign grade - to be implemented"); }
    private void calculateGPA() { System.out.println("Calculate GPA - to be implemented"); }
    private void generateStudentStatistics() { System.out.println("Student statistics - to be implemented"); }
    private void generateCourseStatistics() { System.out.println("Course statistics - to be implemented"); }
    private void generateGPADistribution() { System.out.println("GPA distribution - to be implemented"); }
    private void generateDepartmentReport() { System.out.println("Department report - to be implemented"); }
    private void generateTopStudentsReport() { System.out.println("Top students - to be implemented"); }
    private void importStudentsFromFile() { System.out.println("Import students - to be implemented"); }
    private void importCoursesFromFile() { System.out.println("Import courses - to be implemented"); }
    private void exportStudentsToFile() { System.out.println("Export students - to be implemented"); }
    private void exportCoursesToFile() { System.out.println("Export courses - to be implemented"); }
    private void exportEnrollmentsToFile() { System.out.println("Export enrollments - to be implemented"); }
    private void listBackupFiles() { System.out.println("List backup files - to be implemented"); }
    
    /**
     * Run a demonstration of key features when in non-interactive mode
     */
    private void runDemoMode() {
        System.out.println("Running in DEMO MODE (non-interactive)");
        System.out.println("=".repeat(60));
        
        try {
            // Display sample data
            System.out.println("\n1. Displaying all students:");
            listAllStudents();
            
            System.out.println("\n2. Displaying all courses:");
            listAllCourses();
            
            System.out.println("\n3. Displaying enrollment information:");
            System.out.println("Total active enrollments: " + enrollmentService.getEnrollmentCount());
            
            // Show a student transcript
            System.out.println("\n4. Sample student transcript:");
            Optional<Student> sampleStudent = studentService.findStudentById("STU001");
            if (sampleStudent.isPresent()) {
                System.out.println(sampleStudent.get().getTranscriptInfo());
            }
            
            // Show platform information
            System.out.println("\n5. Java Platform Information:");
            showPlatformInfo();
            
            System.out.println("\nDemo completed successfully!");
            
        } catch (Exception e) {
            System.err.println("Demo error: " + e.getMessage());
        }
        
        running = false;
    }

    /**
     * Initialize some sample data for demonstration
     */
    private void initializeSampleData() {
        try {
            // Add sample students
            studentService.createStudent("STU001", "REG2024001", "John Doe", "john.doe@email.com", LocalDate.of(2000, 5, 15));
            studentService.createStudent("STU002", "REG2024002", "Jane Smith", "jane.smith@email.com", LocalDate.of(1999, 8, 22));
            studentService.createStudent("STU003", "REG2024003", "Mike Johnson", "mike.johnson@email.com", LocalDate.of(2001, 3, 10));
            
            // Add sample courses
            courseService.createCourse("CS101", "Introduction to Computer Science", 3, "PROF001", Semester.FALL, "Computer Science");
            courseService.createCourse("MATH201", "Calculus I", 4, "PROF002", Semester.FALL, "Mathematics");
            courseService.createCourse("PHY101", "Physics I", 3, "PROF003", Semester.SPRING, "Physics");
            
            // Add sample enrollments
            enrollmentService.enrollStudent("STU001", "CS101", "Fall2024");
            enrollmentService.enrollStudent("STU001", "MATH201", "Fall2024");
            enrollmentService.enrollStudent("STU002", "CS101", "Fall2024");
            enrollmentService.enrollStudent("STU003", "PHY101", "Spring2024");
            
        } catch (Exception e) {
            System.err.println("Error initializing sample data: " + e.getMessage());
        }
    }
}