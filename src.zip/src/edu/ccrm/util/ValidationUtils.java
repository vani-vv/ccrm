package edu.ccrm.util;

import java.util.regex.Pattern;

/**
 * Utility class for validation operations
 */
public class ValidationUtils {
    
    // Email validation pattern
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@([A-Za-z0-9.-]+\\.[A-Za-z]{2,})$");
    
    // Student registration number pattern (example: REG2024001)
    private static final Pattern REG_NO_PATTERN = 
        Pattern.compile("^REG\\d{7}$");
    
    // Course code pattern (example: CS101, MATH201)
    private static final Pattern COURSE_CODE_PATTERN = 
        Pattern.compile("^[A-Z]{2,4}\\d{3}$");
    
    // Private constructor to prevent instantiation
    private ValidationUtils() {
        throw new AssertionError("Utility class cannot be instantiated");
    }
    
    /**
     * Validates email address format
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }
    
    /**
     * Validates student registration number format
     */
    public static boolean isValidRegNo(String regNo) {
        if (regNo == null || regNo.trim().isEmpty()) {
            return false;
        }
        return REG_NO_PATTERN.matcher(regNo.trim()).matches();
    }
    
    /**
     * Validates course code format
     */
    public static boolean isValidCourseCode(String courseCode) {
        if (courseCode == null || courseCode.trim().isEmpty()) {
            return false;
        }
        return COURSE_CODE_PATTERN.matcher(courseCode.trim()).matches();
    }
    
    /**
     * Validates if a string is not null or empty
     */
    public static boolean isNotEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }
    
    /**
     * Validates if credits are within valid range
     */
    public static boolean isValidCredits(int credits) {
        return credits > 0 && credits <= 6; // Typical credit range
    }
    
    /**
     * Validates if marks are within valid range (0-100)
     */
    public static boolean isValidMarks(double marks) {
        return marks >= 0.0 && marks <= 100.0;
    }
    
    /**
     * Validates if GPA is within valid range (0-10)
     */
    public static boolean isValidGPA(double gpa) {
        return gpa >= 0.0 && gpa <= 10.0;
    }
    
    /**
     * Validates if a name contains only valid characters
     */
    public static boolean isValidName(String name) {
        if (!isNotEmpty(name)) {
            return false;
        }
        // Allow letters, spaces, apostrophes, hyphens, and dots
        return name.matches("^[A-Za-z\\s'.-]+$") && name.length() <= 100;
    }
    
    /**
     * Sanitizes input by trimming whitespace and removing extra spaces
     */
    public static String sanitize(String input) {
        if (input == null) {
            return "";
        }
        return input.trim().replaceAll("\\s+", " ");
    }
    
    /**
     * Validates if an ID follows the expected format
     */
    public static boolean isValidId(String id) {
        if (!isNotEmpty(id)) {
            return false;
        }
        // Allow alphanumeric characters and underscores, 3-20 characters
        return id.matches("^[A-Za-z0-9_]{3,20}$");
    }
}